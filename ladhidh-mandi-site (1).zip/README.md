# Ladhidh Mandi - mobile QR ordering

## Customer website (mobile-only)
Flow: scan table QR > congratulations + fireworks > tap > "Order from your phone" > menu > cart > checkout > live order status.

1. Upload `index.html`, the `assets` folder and `.nojekyll` to a GitHub repo (do NOT upload `backend`).
2. Settings > Pages > Deploy from branch > main > / (root).
3. Table QR codes must open: `https://USERNAME.github.io/REPO/?table=01` (02, 03 ...). The table number is kept on every screen.
4. In `index.html` find `CFG` and set `API_URL` (your server address) and `WHATSAPP` (country code + number).

Without `API_URL` the site runs in DEMO mode: orders are NOT sent, and the status screen simulates progress so you can show the owner.

## Owner dashboard + server (backend folder)
GitHub Pages cannot run servers. Host `backend/` on Render, Railway or any Node host.
1. `cd backend && npm install && ADMIN_KEY=yourSecret npm start`
2. Set env vars: `ADMIN_KEY` (secret), `ALLOWED_ORIGIN` (your GitHub Pages address).
3. Open `https://YOUR-SERVER/admin/` on the owner's phone, log in with the admin key.
4. Orders appear within 4 seconds with a beep. Tap ACCEPT / REJECT, then PREPARING > READY > SERVED. The customer sees each change live.
5. The "Table QR codes" tab makes printable QR codes for every table.

## Admin inside the website
At the bottom of the menu there is an ADMIN button. It asks for the admin key (the same key you set as `ADMIN_KEY` on the server). Then you get:
- TABLES: tap a table, see its orders, tick which orders go on the bill, CHOOSE BILL, set GST %, PRINT BILL, then PAID · CLOSE TABLE.
- ADD ITEMS: staff can add food to a table from the menu.
- ORDERS: accept, reject, preparing, ready, served.
- + ADD TABLE / - REMOVE LAST changes the number of tables (stored on this device).
Set `ADMIN_KEY=Ladhidh@2026Owner` on your server (change it later; it was shared in a chat).
IMPORTANT: with no server (demo mode) the key is only checked inside the page, so it is NOT real security. Use the server for real orders.

## Menu and pictures
`ladhidh-menu.html` opens by double-click and shows every item, price and picture (print it or save as PDF). The pictures are 2D illustrations in `assets/menu/` (one SVG per item); replace any file with a real photo of the same name to upgrade it.

## Limits of this version
- Orders are stored in `orders.json`. Free hosts may erase it on restart; use a persistent disk or a database for real use.
- Prices are sent by the customer's phone; before selling to others, keep the menu on the server and check prices there.
- Waiter app, kitchen screen, payments and multi-restaurant accounts are not built yet.
- The food pictures are illustrative; replace `assets/f-*.png` with real photos.
