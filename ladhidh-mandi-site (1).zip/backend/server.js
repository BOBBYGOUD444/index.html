// Ladhidh Mandi order API. Run: npm install && ADMIN_KEY=yourSecret npm start
const express=require('express'),cors=require('cors'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const app=express(),FILE=path.join(__dirname,'orders.json'),KEY=process.env.ADMIN_KEY||'change-me';
const ST=['New','Accepted','Preparing','Ready','Served','Rejected','Cancelled'];
app.use(cors({origin:process.env.ALLOWED_ORIGIN||'*'}));app.use(express.json({limit:'50kb'}));
const read=()=>{try{return JSON.parse(fs.readFileSync(FILE))}catch{return[]}},write=o=>fs.writeFileSync(FILE,JSON.stringify(o,null,1));
const auth=(q,s,n)=>q.get('x-admin-key')===KEY?n():s.status(401).json({error:'Unauthorized'});
const hits={};app.use('/api/orders',(q,s,n)=>{if(q.method!=='POST')return n();const k=q.ip,t=Date.now();hits[k]=(hits[k]||[]).filter(x=>t-x<60000);if(hits[k].length>=30)return s.status(429).json({error:'Too many orders, wait a minute'});hits[k].push(t);n()});
// Customer places an order (duplicate-safe: same clientId returns the same order)
app.post('/api/orders',(q,s)=>{const b=q.body||{};
 if(!b.name||!/^[0-9+ ]{7,15}$/.test(b.phone||'')||!b.table||!Array.isArray(b.items)||!b.items.length)return s.status(400).json({error:'Invalid order'});
 const all=read(),cid=String(b.clientId||'').slice(0,80),dup=cid&&all.find(o=>o.clientId===cid);
 if(dup)return s.status(200).json({id:dup.id,token:dup.token,total:dup.total});
 const items=b.items.slice(0,50).map(i=>({name:String(i.name).slice(0,80),qty:Math.max(1,Math.min(20,+i.qty||1)),price:Math.max(0,+i.price||0)}));
 const o={id:(all.at(-1)?.id||1000)+1,token:crypto.randomBytes(8).toString('hex'),clientId:cid,table:String(b.table).slice(0,6),name:String(b.name).slice(0,60),phone:b.phone,notes:String(b.notes||'').slice(0,300),items,total:items.reduce((a,i)=>a+i.qty*i.price,0),status:'New',paid:false,at:new Date().toISOString()};
 all.push(o);write(all);s.status(201).json({id:o.id,token:o.token,total:o.total})});
// Customer checks live status (needs the private token from the order)
app.get('/api/orders/:id',(q,s)=>{const o=read().find(x=>x.id==q.params.id);if(!o||o.token!==q.query.token)return s.sendStatus(404);s.json({id:o.id,status:o.status,table:o.table})});
// Owner
app.get('/api/orders',auth,(q,s)=>s.json(read().slice(-300).reverse().map(({token,...o})=>o)));
app.patch('/api/orders/:id',auth,(q,s)=>{const all=read(),o=all.find(x=>x.id==q.params.id),st=q.body.status;if(!o)return s.sendStatus(404);if(st&&!ST.includes(st))return s.status(400).json({error:'Bad status'});if(typeof q.body.paid==='boolean')o.paid=q.body.paid;if(st)o.status=st;write(all);s.json({id:o.id,status:o.status,paid:!!o.paid})});
app.use('/admin',express.static(path.join(__dirname,'public')));
app.listen(process.env.PORT||3000,()=>console.log('API running'));
